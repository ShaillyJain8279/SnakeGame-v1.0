#SNAKE GAME
This is one of the game that everyone has played in his/her childhood. This is snake game where a snake is trapped within a maze and is 
constantly served food. The snake keeps on eating the food and growing. 


#FEATURES
1. You can change the direction of movement of snake using arrow keys on your keyboard.
2. You can adjust the speed of movement of snake using the slider given in the application. Your score will be adjusted according to your speed.



#REQUIREMENTS
Make sure you have installed OpenJDK8 Java Runtime Environment


#INSTALLATION
You need not to install anything to try this application.
You are given a jar file(Snake.jar), you just need to
double click on it and the application will start for you.
*Make sure you do not delete .colors.txt file for better look and feel*



#RUNNING ISSUE
Depending of the platform(OS) you are using it may be possible that
your OS may not give execution permission to the given jar file.
If so then there are two ways to fix this issue i.e.
1) Change the permission of the jar file and mark it is as executable
2) Use terminal and execute the following command:

##a) First of all navigate to the directory wherever Snake.jar is located.
##b) Execute java -jar Snake.jar


#COPYRIGHT
Copyright© 2019
All rights reserved
Shailly Jain (Meerut Institute of Engineering and Technology) 
(shaillyjain1512@gmail.com)
